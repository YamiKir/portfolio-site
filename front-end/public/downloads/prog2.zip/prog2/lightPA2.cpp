//  Adding lighting effects on two objects: sphere and icosahedron
#include <glut.h>
#include <stdlib.h>

static GLfloat rot1 = 0.0, rot2 = 00.0;

void init(void)
{
    glClearColor(0.2, 0.2, 0.2, 0.0);

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    GLfloat light_position[] = { 0.0, 0.0, 5.0, 0.0 }; //Specifies the light position of (0.0, 0.0, 5.0, 0.0) to implement a directional light source
    GLfloat light_ambient[] = { 0.0, 0.0, 0.0, 1.0 };
    GLfloat light_diffuse[] = { 1.0, 1.0, 0.0, 1.0 };  
    GLfloat light_specular[] = { 0.0, 0.0, 0.0, 1.0 }; // Set ambient and specular light components to zero (0.0, 0.0, 0.0, 1.0) and
                                                       //diffuse component to yellow color(1.0, 1.0, 0.0, 1.0)
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular); //gives the properities 
    //glDisable(GL_LIGHT0);

    glEnable(GL_LIGHT1);
    GLfloat light_position1[] = { 0.0, 0.0, 5.0, 1.0 }; //Specifies the light position of (0.0, 0.0, 5.0, 1.0) to implement a directional light source
    GLfloat light_ambient1[] = { 0.0, 0.0, 0.0, 1.0 };
    GLfloat light_diffuse1[] = { 0.0, 0.0, 0.0, 1.0 };
    GLfloat light_specular1[] = { 1.0, 1.0, 1.0, 1.0 }; // Set specular light components to (1.0, 1.0, 1.0, 1.0) and
                                                        // ambient and diffuse component to zero (0.0, 0.0, 0.0, 1.0)
    glLightfv(GL_LIGHT1, GL_POSITION, light_position1);
    glLightfv(GL_LIGHT1, GL_AMBIENT, light_ambient1);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuse1);
    glLightfv(GL_LIGHT1, GL_SPECULAR, light_specular1); //gives the properities 

    glEnable(GL_DEPTH_TEST);


    
   

}

void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glPushMatrix();
    glRotatef(rot1, 0.0, 1.0, 0.0);

    GLfloat sphere_emission[] = { 1.0, 0.0, 0.0, 1.0 };
    GLfloat sphere_diffuse[] = { 0.5, 0.5, 0.5, 1.0 };
    GLfloat sphere_ambient[] = { 0.0, 0.0, 0.0, 1.0 };
    GLfloat sphere_specular[] = { 0.0, 0.0, 0.0, 1.0 }; //For sphere, specify emission coefficient as full red (1.0, 0.0, 0.0, 1.0),
    //diffuse coefficient as half - gray(0.5, 0.5, 0.5, 1.0), and set both ambient and specular coefficients to zero.
    glMaterialfv(GL_FRONT, GL_EMISSION, sphere_emission);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, sphere_diffuse);
    glMaterialfv(GL_FRONT, GL_AMBIENT, sphere_ambient);
    glMaterialfv(GL_FRONT, GL_SPECULAR, sphere_specular); //gives the properities 


    glutSolidSphere(1.0, 100, 100);
    glTranslatef(4.0, 0.0, 0.0);

    GLfloat icosahedron_diffuse[] = { 0.0, 1.0, 1.0, 1.0 };//For icosahedron, specify diffuse coefficient (0.0, 1.0. 1.0, 1.0)
    GLfloat icosahedron_specular[] = { 1.0, 1.0, 1.0, 1.0 };//and specular coefficient (1.0,1.0, 1.0, 1.0)
    GLfloat icosahedron_ambmission[] = { 0.0, 0.0, 0.0, 1.0 };//Set both ambient and emission coefficients to zero.
    GLfloat shininess = 100.0;                              //and shininess factor of 100.

    glMaterialfv(GL_FRONT, GL_EMISSION, icosahedron_ambmission);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, icosahedron_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, icosahedron_specular);
    glMaterialfv(GL_FRONT, GL_AMBIENT, icosahedron_ambmission);
    glMaterialf(GL_FRONT, GL_SHININESS, shininess); //gives the properities 

    glRotatef(rot2, 0.5, 1.0, 0.0);
    glutSolidIcosahedron();
    glPopMatrix();
    glutSwapBuffers();
}

void yearDisplay(void)
{
    rot1 = rot1 + 1.0;
    if (rot1 > 360.0)
        rot1 = rot1 - 360.0;
    rot2 = rot2 + 2.0;
    if (rot2 > 360.0)
        rot2 = rot2 - 360.0;
    glutPostRedisplay();
}

void reshape(int w, int h)
{
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, (GLfloat)w / (GLfloat)h, 1.0, 20.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(0.0, 0.0, 7.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
}

void keyboard(unsigned char key, int x, int y)
{
    switch (key) {
    case 'y':
        glutIdleFunc(yearDisplay);
        break;
    case 'n':
        glutIdleFunc(NULL);
        break;
    case 27:
        exit(0);
        break;
    default:
        break;
    }
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1000, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Lighting");
    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutMainLoop();
    return 0;
}
