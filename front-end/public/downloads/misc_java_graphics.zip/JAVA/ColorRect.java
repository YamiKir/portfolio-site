import java.applet.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.*;

public class ColorRect extends Applet implements ActionListener {


	int r,g,b;

	//addition of 2 integers
	String s1,s2,s3;
	//Integer

	JTextField tf1,tf2,tf3;
	JButton b1;
	Color c;

	public void init(){
		r=0;
		g=0;
		b=0;
		c= new Color(0,0,0);
		tf1=new JTextField(20);
		this.add(tf1);
		tf2= new JTextField(20);
		this.add(tf2);
		tf3= new JTextField(20);
		this.add(tf3);

		b1= new JButton(":)");
		b1.addActionListener(this);
		this.add(b1);



	//complete the above program with ints


}
public void	actionPerformed(ActionEvent e){
		String s1=tf1.getText();
		String s2=tf2.getText();
		String s3=tf3.getText();

			try{

			r=Integer.parseInt(s1);
			g=Integer.parseInt(s2);
			b=Integer.parseInt(s3);


		}
		catch (NumberFormatException p )
		{
		}
	c=new Color(r,g,b);
	repaint();
}
public void paint(Graphics g){
	g.fillRect(25,100,150,150);
}
}