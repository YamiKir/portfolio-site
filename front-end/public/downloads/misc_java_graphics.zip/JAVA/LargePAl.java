import java.awt*;

public class LargePAl{

   public static void main (String[] args){
   
   
   
   
   
   }
   
   
   public boolean PalTester(String x){
   Scanner scan= new Scanner (x);
   boolean pal=true;
   while (scan.hasNext()||pal==true){
   // 1if string character equals other side char repeat until no more characeters
   //1 n=number s.n==s.(l-1-n) if string is counted 0-(l+1)
   if (/*1*/) pal==true;
   else pal==false;
   
   
   
   return pal;
   
   }
   