import java.awt.*;

public class Lovure
{
   public static void main(String[] args){
      
      System.out.println("hi");


   }

}