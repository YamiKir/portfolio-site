import java.applet.*;
import javax.swing.*;


public class StringToInteger extends Applet {
  
	
   int num1,num2,ans;
	//addition of 2 integers
   String s1,s2,s3;
	//Integer
	
   JTextField tf1,tf2,tf3;
	
   public void init() {
      num1=0;
      num2=0;
      tf1=new JTextField(20);
      this.add(tf1);
      tf2= new JTextField(20);
      tf3= new JTextField(40);
   
      s1=tf1.getText();
      s2=tf2.getText();
   	//convert strings to int
      num1=Integer.parseInt(s1);
      num2=Integer.parseInt(s2);
      ans=num1+num2;
   	//same with num2
   	//add num1 and num2 store into ans
   	//convert ans to a String
      s3=String.valueOf(ans);
   	//put the string s3 into tf3
      tf3.setText(s3);
   	
   	
   	
   }
	
	//complete the above program with ints
	
	
}