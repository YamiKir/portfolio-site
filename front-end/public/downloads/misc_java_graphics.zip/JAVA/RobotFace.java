import java.awt.*;
import java.applet.*;

public class RobotFace extends Applet{
	public void paint(Graphics g){
		g.setColor(Color.GRAY);
		g.drawRect(25,25,150,150);
		g.fillRect(25,25,150,150);
		g.setColor(Color.yellow);
		g.drawOval(50,50,20,40);
		g.fillOval(50,50,20,40);
		g.drawOval(120,50,20,40);
		g.fillOval(120,50,20,40);
		g.setColor(Color.white);
		g.drawOval (75,130,40,20);
		g.fillOval (75,130,40,20);
		g.setColor(Color.white);
		g.drawRect(25,40,20,20);
		g.fillRect(25,40,20,20);



	}

}