   import java.applet.*;
   import javax.swing.*;
   import java.awt.*;

public class CorePresser extends Applet {

   public void init(){










   }
 public void buttonModel(){
 public T
 
 
 
 }
