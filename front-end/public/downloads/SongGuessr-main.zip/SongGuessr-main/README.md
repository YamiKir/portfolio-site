<h1>SongGuessr - SASE Geaxu Hack 24'</h1>
<h2>What is it?</h2>
Learn songs from from diffrent cultures! Take a guess where the song is from and see how high of a streak you can get!

<h2>How to run</h2>
*run npm install <br/>
*cd into front end <br/>
*in terminal type "npm run-script dev" <br/>
*in a new terminal run the "spotify-integration.py" <br/>
*open up "http://localhost:5173/" enjoy!
