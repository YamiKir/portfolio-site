window.onload = function init() {

  var canvas = document.getElementById("gl-canvas");
  gl  = canvas.getContext('webgl2');

  gl.clearColor (0.9, 0.9, 0.9, 1.0); 

  var vertices1 = [0.3, -0.3,0.0, 0.0,0.3,0.0, -0.3,-0.3,0.0];
  var vertices2 = [0.4,-0.4,0.0, 0.4,0.4,0.0, -0.4,0.4,0.0, -0.4,-0.4,0.0];

// Create two program shaders: program1 and program2
  var program1 = initShaders(gl, "vertex-shader1", "fragment-shader1");
  var program2 = initShaders(gl, "vertex-shader2", "fragment-shader2");

// Create two vertex buffer objects: vertex_buffer1 and vertex_buffer2
  var vertex_buffer1 = gl.createBuffer();
  var vertex_buffer2 = gl.createBuffer();
  
  gl.bindBuffer (gl.ARRAY_BUFFER, vertex_buffer1);
  gl.bufferData (gl.ARRAY_BUFFER, new Float32Array(vertices1), gl.STATIC_DRAW);

  gl.bindBuffer(gl.ARRAY_BUFFER, vertex_buffer2);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices2), gl.STATIC_DRAW);

  var transMatrix = new Float32Array([
    0.5, 0.0, 0.0, 0.0,
    0.0, 2.0, 0.0, 0.0,
    0.0, 0.0, 1.0, 0.0,
    0.7, 0.0, 0.0, 1.0
]);
  
  function render () {
     gl.clear (gl.COLOR_BUFFER_BIT);

// Use the program1 and vertex_array1 to draw a triangle
     gl.useProgram(program1);
     gl.bindBuffer (gl.ARRAY_BUFFER, vertex_buffer1);
     var positionLoc = gl.getAttribLocation(program1, "aPosition");
     gl.vertexAttribPointer (positionLoc, 3, gl.FLOAT, false, 0, 0);
     gl.enableVertexAttribArray (positionLoc);
     gl.drawArrays (gl.TRIANGLES, 0, 3);

     /* Add code to use program2 and vertex-array2, 
    set up the transformation matrix, and draw the vertex array. */
    // Use the program2 and vertex_array2 to draw a blue rectangle

     gl.useProgram(program2);
     gl.bindBuffer(gl.ARRAY_BUFFER, vertex_buffer2);
     var positionLoc2 = gl.getAttribLocation(program2, "aPosition");
     gl.vertexAttribPointer(positionLoc2, 3, gl.FLOAT, false, 0, 0);
     gl.enableVertexAttribArray(positionLoc2);

     //transformation matrix
    var uTransLoc = gl.getUniformLocation(program2, "uTM");
    gl.uniformMatrix4fv(uTransLoc, false, transMatrix);


    gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);
  }

  render();
};

