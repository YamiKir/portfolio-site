window.onload = function init() {
  var canvas = document.getElementById("gl-canvas");
  gl  = canvas.getContext('webgl2');

  gl.clearColor (0.9, 0.9, 0.9, 1.0); 

  var program = initShaders(gl, "vertex-shader", "fragment-shader");
  gl.useProgram(program);

  var vertices = [0.0, 0.8, 0.0, 0.7, 0.4, 0.0, 0.7, -0.4, 0.0, 0.0, -0.8, 0.0, -0.7, -0.4, 0.0, -0.7, 0.4, 0.0]; //changed
  var colors = [1, 0, 0,  1, 1, 0,  0, 1, 0,  0, 1, 1, 0, 0, 1, 1, 0, 1]; //Use six different colors red, yellow, green, cyan, blue, and magenta, respectively and specify the corresponding color array:

// Create an empty buffer object and store vertex data
  var vertex_buffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, vertex_buffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);

// Create an empty buffer object and store color data
  var color_buffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, color_buffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(colors), gl.STATIC_DRAW);

/* Create program shader using the vertex and fragment shaders and link */
  var program = initShaders(gl, "vertex-shader", "fragment-shader");
  gl.useProgram(program)

/* Bind vertex buffer object, get the attribute location, associate 
the shader program to the data, enable the array */
  gl.bindBuffer(gl.ARRAY_BUFFER, vertex_buffer);
  var positionLoc = gl.getAttribLocation (program, "aPosition");
  gl.vertexAttribPointer (positionLoc, 3, gl.FLOAT, false, 0, 0);
  gl.enableVertexAttribArray (positionLoc);

// Below implement binding, locating, associating, and enabling color array data
  gl.bindBuffer(gl.ARRAY_BUFFER, color_buffer);
  var colorLoc = gl.getAttribLocation(program, "aColor");
  gl.vertexAttribPointer(colorLoc, 3, gl.FLOAT, false, 0, 0);
  gl.enableVertexAttribArray(colorLoc);

// Call the drawing function

  render();

};


// Draw the vertex array data
function render() {
  gl.clear (gl.COLOR_BUFFER_BIT);
  gl.drawArrays(gl.POINTS, 0, 6);
  gl.drawArrays(gl.TRIANGLE_FAN, 0, 6);
}

