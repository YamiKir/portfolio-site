#include<iostream>
#include "MyStringImpl.cpp"
using namespace std;

//create a node

struct node{
	MyString name;
	int age;
	//address of next node
	node *next;	
};
class LinkedListADT{
	private: node *head;
	 		 node *current;
			 node *previous;
			 node *end;
			 	
	public: //5 functions
	        LinkedListADT(); //create function
	        void add(node *temp);
	        void retrieve(node *temp);
	        void deleteNode(node *temp);
	        void print_list();
};
LinkedListADT::LinkedListADT(){
 			current=new node;
			head=new node;
			previous=new node;
			end=new node;
			head=NULL;
}
void LinkedListADT::add(node *temp){
	if(head!=NULL) cout<<"HEAD IS CURRENTLY "<<head->name<<endl;
	cout<<"Temp's name "<<temp->name<<endl;
	 //if(temp->name>head->name) cout<<"TRUE!\n";
	if(head==NULL){
		temp->next=NULL;
		head=temp;
		cout<<"case 0\n";
	}
	 if(temp->name<head->name){
		temp->next=head;
		head=temp;
		cout<<"case 1\n";
	}	
	 else if((temp->name>head->name&&temp->name<end->name)){
	 	cout<<"case 2 begins\n";
		current=head;
		while((temp->name>current->name)){
			previous=current;
			current=current->next;
		}
		temp->next=current;
		previous->next=temp;
		cout<<"case 2\n";
	}
	else if(temp->name>end->name) {
		//case 3: End of list
   	current=head;
   	while(current->next!=NULL){
   		current=current->next;
	   }
	   current->next=temp;
	   current=temp;
	   current->next=NULL;
	   cout<<"case 3\n";
   }
   current=head;
   while(current->next!=NULL){
   		current=current->next;
	   }
	   end=current;
	   cout<<"Ender's name "<<end->name<<endl<<endl;
}
void LinkedListADT::retrieve(node *temp){
	current=head;
	while(current!=temp&&current->next!=NULL){
		current=current->next;
	}
	if(current==temp)cout<<current->name<<" "<<current->age<<" and the next item in the link list is "<< current->next<<endl;
	else cout<<"not found man";

}
void LinkedListADT::deleteNode(node *temp){
	//delete temp
	while(current!=NULL){
		if(temp->name==current->name){
			previous->next=current->next;
			current=previous;
		}
		previous=current;
		current=current->next;
	}
	
}
void LinkedListADT::print_list(){
	node *temp;
	temp=new node;
	if(head!=NULL){
		current=head;
	
		while(current!=NULL){
			cout<<current->name<<endl;
			current=current->next;
		}
	}
	
	
}

int main(){
	LinkedListADT test;
	MyString tName;
	node *temp;
	while(true){
	temp= new node;
	cout<<"add a Node (string)\n";
	cin>>tName;
	temp->name=tName;
	test.add(temp);
	test.print_list();
}
}
