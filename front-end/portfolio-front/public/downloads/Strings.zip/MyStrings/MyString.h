#include<iostream>
using namespace std;

#ifndef MYSTRING_H
const int MAX=50;
class MyString{
	private:
		char str[MAX];
		int length;
	public:
		MyString(); //default constr
		MyString(char word[]);
		void setString(char word[]);
		void setLength(int len);
		char* getString();
		int getLength();
	    MyString copyString(MyString s);
	
	
};
#define MYSTRING_H
#endif
