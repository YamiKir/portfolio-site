//Koby Ramsey 
//Data Structures- 10TR
#include<iostream>
#include "MyStringImpl.cpp"
using namespace std;

//create a node

struct node{
	MyString name;
	int age;
	//address of next node
	node *next;	
};
class LinkedListADT{
	private: node *head;
	 		 node *current;
			 node *previous;
			 node *end;	 	
	public: //5 functions
	        LinkedListADT(); //create function
	        void add(node *temp);//add
	        void retrieve(node *temp);//search for node
	        void deleteNode(node *temp);//delete target node
	        void print_list();//display
	        void init();//wipes nodes
};
 LinkedListADT::LinkedListADT(){//constructs
 			current=new node;
			head=new node;
			previous=new node;
			end=new node;
			head=NULL;
}
void LinkedListADT::add(node *temp){//adds node to the list depending on case
	if(head==NULL){//case 0:adds the very first node to the list and assigns it the value of head
		temp->next=NULL;
		head=temp;
	}
	 if(temp->name<head->name){//case 1:adds node to the beginning of the list and assigns it the value of head
		temp->next=head;
		head=temp;
	}	
	 else if((temp->name>head->name&&temp->name<end->name)){ //case 2:adds node to the middle of the list
		current=head;
		while((temp->name>current->name)){
			previous=current;
			current=current->next;
		}
		temp->next=current;
		previous->next=temp;
	}
	else if(temp->name>end->name) {//case 3: adds node to the end of the list (with a help of a class variable titled "end"
		//case 3: End of list
   	current=head;
   	while(current->next!=NULL){
   		current=current->next;
	   }
	   current->next=temp;
	   current=temp;
	   current->next=NULL;
	   
   }
   //assigns a node value to end
   current=head;
   while(current->next!=NULL){
   		current=current->next;
	   }
	   end=current;
}
void LinkedListADT::retrieve(node *temp){//searches for a node in the list by name and displays it and  what the next node would be
	current=head;
	while(current->name!=temp->name){
		current=current->next;
	}
	if(current->name==temp->name)cout<<current->name<<" and the next item in the link list is "<< current->next->name<<endl;
	else cout<<"NODE NOT FOUND\n";

}
void LinkedListADT::deleteNode(node *temp){//deletes target node from the list
	current=head;
	while(current!=NULL){
		if(temp->name==head->name){
			head=head->next;
			current=head;
		}
		if(temp->name==current->name&&current!=head){
			previous->next=current->next;
			current=previous;
		}
		previous=current;
		current=current->next;
	}
	cout<<"NODE HAS BEEN OBLITERATED\n";
}
void LinkedListADT::print_list(){//displays the entire list
	node *temp;
	temp=new node;
	if(head!=NULL){
		current=head;
	
		while(current!=NULL){
			cout<<current->name<<endl;
			current=current->next;
		}
	}
	
	
}
void LinkedListADT::init(){//resets the class nodes
			current=new node;
			head=new node;
			previous=new node;
			end=new node;
			head=NULL;
}
int showMenu(){//displays the menu
	int choice; 
	//I had to... 
	cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~\n1. Create ---> creates or initializes a linked list using a constructor\n2. initialize all nodes (head, current, previous to NULL)\n3. add_node (book calls it store) --> uses the 3 cases\n4. remove --> deletes target node\n5. retrieve --> displays the target node\n6. print_list\n0. QUIT!\n~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";                                                                                                                                     
	cin>>choice;
	return choice;
}
void handleChoice(int choice,LinkedListADT list){//handles the choice from showMenu and loops itself
	node *temp;
	while(choice!=0){
	temp= new node;
	MyString response;
	switch(choice){
		case 1:
			//create
			cout<<"the list has been created~!\n";
			break;
		case 2:
			//initalize all nodes (head, current, previous to NULL)
			list.init();
			cout<<"nodes have been initalized\n";
			break;
		case 3:
			//add node
			cin>>response;
			temp->name=response;
			list.add(temp);
			break;
		case 4:
			//remove target node
			cin>>response;
			temp->name=response;
			list.deleteNode(temp);
			choice=showMenu();
			break;
		case 5://retrieve a node
			cin>>response;
			temp->name=response;
			 list.retrieve(temp);
			break;
		case 6:
			//print nodes;
			list.print_list();
			break;
		case 0://QUIT
			break;
	}
	choice=showMenu();
}
}
int main(){
	LinkedListADT list;
	handleChoice(showMenu(), list);
	}
	
