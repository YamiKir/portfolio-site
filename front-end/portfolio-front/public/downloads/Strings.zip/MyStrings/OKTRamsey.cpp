#include<iostream>
#include "MyStringImpl.cpp"
using namespace std;

typedef int element;

class Association{
	
	private:
		MyString key;
		element value;
		
    public:
    	Association();
    	Association(MyString keyy, element item);
    	//Association(Assoctiation a);
    	void setKey(MyString keyy);
    	void setValue(element item);
    	MyString getKey();
    	element getValue();
};

Association::Association(){
	//key="AAAA";
	value=0;
}
Association::Association(MyString keyy, element item){
	key=keyy;
	value=item;
}
void Association::setKey(MyString keyy){
	key=keyy;
}
void Association::setValue(element val){
	value=val;
}
element Association::getValue(){
	return value;
}
MyString Association::getKey(){
	return key;
}
class One_Key_TableADT{
	private:
		Association data[MAX]; //table of max 50 items
		int size;
	public:
		//operations
		One_Key_TableADT(); //create
		bool empty(); //return true if length is 0
		int getLength(); //returns the length of table
		void store(MyString keyy, element item);//sort as you go
		void remove(MyString target);
		bool retrieve(MyString target);
};

One_Key_TableADT::One_Key_TableADT(){   
	size=0;
	data[0].setKey("AAAA");
	data[0].setValue(0);
}
bool  One_Key_TableADT::empty(){
	if (size==0) return true;
	else return false;
}
element  One_Key_TableADT::getLength(){
	return size;
}
bool One_Key_TableADT::retrieve(MyString target){
	int low=0,high=size-1, middle;
	bool success=false;
	MyString keyy;
	if(!empty()){
		while((low<=high)&&!success){
			middle=(low+high)/2;
			keyy=data[middle].getKey();
			cout<<data[middle].getKey();
			if(keyy==target)
				success=true;
			else if(keyy>target){
					high=middle-1;
					
				}
				else low=middle+1;
		}
		if(success){
			cout<<"Found your target: "<<keyy<<"'s value = "<<data[middle].getValue()<<endl;
			return true;
		}
		else {
			cout<<"Target not found\n";
			return false;
		}
	}
	
}

void One_Key_TableADT::store(MyString keyy, element item){
	int index=0;
	MyString kStore,kSwap;
	element vStore,vSwap;
	
	if(!empty()){

		while(data[index].getKey()<keyy&&index!=size){
			index++;
		}
		if(data[index].getKey()==keyy){
			data[index].setValue(item);
		}
		if(index==size){
			data[index].setKey(keyy);
			data[index].setValue(item);
		}
		else{
			vStore=item;
			kStore=keyy;
		
			for(int j=index;j<MAX;j++){
				//store current into a future (?)Store
				kSwap=data[j].getKey();
				vSwap=data[j].getValue();
				//Replace
				data[j].setKey(kStore);
				data[j].setValue(vStore);
				//replace (?)Store with (?)Swap
				vStore=vSwap;
				kStore=kSwap;			
				}
		}
	} else{
		data[0].setKey(keyy);
		data[0].setValue(item);
	}
	size++;
}
void One_Key_TableADT::remove(MyString target){
	int low=0,high=size-1, middle;
	bool success=false;
	MyString keyy;
	if(!empty()){
		while((low<=high)&&!success){
			middle=(low+high)/2;
			keyy=data[middle].getKey();
			if(keyy==target)
				success=true;
			else if(keyy>target){
					high=middle-1;
					
				}
				else low=middle+1;
		}
		if(success){
			for(int i=middle;i<MAX;i++){
				data[i].setKey(data[i+1].getKey());
				data[i].setValue(data[i+1].getValue());
			}
	}
		else {
			cout<<"Target not found\n";
		}
	}
	
}
int showMenu(){
	int choice;
	cout<<"One Key Table Menu:\n-------------------\nPress 1 to add to table (ask for name and waist size)\nPress 2 to find the length of table (displays the length)\nPress 3 to see if table is empty\nPress 4 to remove from table (ask for name)\nPress 5 to retrieve from table (ask for name)\n\nPress 0 to stop\n--------------------------------------------------------------\n";
	cin>>choice;
	return choice;
};
bool choiceHandler(int choice,One_Key_TableADT& table){
	MyString name;
	int size;
	switch(choice){
		case 1://add to table
			cout<<"What's the person's name and then waist size?\n";
			cin>>name>>size;
			table.store(name,size);
			break;
		case 2://find length
			cout<<"The length of the table is: "<<table.getLength()<<endl;
			break;
		case 3://see if table is empty
			if(table.empty()) cout<<"The table is empty\n";
			else cout<<"The table wasn't empty\n";
			break;
		case 4://remove from table
			cout<<"What's the name of the entry you want to remove?\n";
			cin>>name;
			table.remove(name);
			break;
		case 5://retrieve table
			cout<<"What's the name of the entry you want to retrieve?\n";
			cin>>name;
			table.retrieve(name);
			break;
		case 0:
			break;
}
if (!choice)return false;
else return true;};
int main(){
	One_Key_TableADT okt;
	bool choice=true;
		while(choice){
		choice=choiceHandler(showMenu(), okt);
		cout<<"-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  \n";
		}
		
		
	}
/*
One Key Table Specifications:
	
	
Complete class Association and class One_Key_Table
Create a showMenu function that displays the following menu:
	Press 1 to add to table (ask for name and waist size)
	//if person already exists in table then update waist size
	Press 2 to find the length of table (displays the length)
	Press 3 to see if table is empty 
	Press 4 to remove from table (ask for name)
	//if person is not in table return false along with a message
	Press 5 to retrieve from table (ask for name)
	//if person is not in table return false along with a message
	
	*/







