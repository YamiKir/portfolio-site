#include "MyString.h"
#include<cmath>
#include <cstring>
#include<iostream>
using namespace std;

MyString::MyString(){
	strcpy(str,"AAA");
	length=strlen(str);	
}

MyString::MyString(char word[]){
	strcpy(str,word);
	length=strlen(str);
}
void MyString::setString(char word[]){
	strcpy(str,word);
}
void MyString::setLength(int len){
	length=len;
}
char* MyString::getString(){
	return str;
	
}


int MyString::getLength(){
	return length;	
}

MyString MyString::copyString(MyString s){
	strcpy(str,s.getString());
	length=s.getLength();	
	return *this;
}

//non member functions
//MyString add2Strings(MyString s1, MyString s2);
int length(MyString s);
//bool compare2Strings(MyString s1, MyString s2); //equal or not
//operator overloading

MyString add2Strings(MyString s1, MyString s2){
	MyString str(strcat(s1.getString(),s2.getString()));
	return str;
	
}
int length(MyString s){
	return	s.getLength();
}
bool compare2Strings(MyString s1, MyString s2){
	return strcmp(s1.getString(),s2.getString());
}
MyString operator+(MyString s1, MyString s2){
	MyString str(strcat(s1.getString(),s2.getString()));
	return str;
	
}
MyString operator+=(MyString& s1, MyString s2){
	return s1=s1+s2;
	
}


bool operator==(MyString s1, MyString s2){
	
	if(strcmp(s1.getString(),s2.getString())==0)
		return true;
	else return false;

}

istream& operator>>(istream &is, MyString &s){
	char temp[MAX];
	is>>temp;
	s.setString(temp);
	s.setLength(strlen(temp));
	return is;
	
}
bool operator!=(MyString s1, MyString s2){
		if(strcmp(s1.getString(),s2.getString())!=0)
		return true;
	else return false;
}

bool operator>(MyString s1, MyString s2){
		if(strcmp(s1.getString(),s2.getString())>0)
		return true;
	else return false;
}
bool operator<(MyString s1, MyString s2){
		if(strcmp(s1.getString(),s2.getString())<0)
		return true;
	else return false;
}
bool operator<=(MyString s1, MyString s2){
		if(strcmp(s1.getString(),s2.getString())<=0)
		return true;
	else return false;
}
bool operator>=(MyString s1, MyString s2){
		if(strcmp(s1.getString(),s2.getString())>=0)
		return true;
	else return false;
}

ostream& operator<<(ostream &os, MyString s){
	os<<s.getString();
	return os;
}


