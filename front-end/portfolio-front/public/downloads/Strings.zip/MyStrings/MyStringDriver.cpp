#include "MyString.h"
#include "MyStringImpl.cpp"
#include<cstring>
#include<iostream>
using namespace std;

int main(){
	MyString str1;
	return 0;
}
