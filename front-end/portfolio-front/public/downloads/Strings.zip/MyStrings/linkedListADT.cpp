/*
1. Create a linked list by inserting nodes in alphabetical order - Due on Thursday
2. Print the contents of your list
3. Ask user if he wants to delete a node
*/

#include<iostream>
#include "MyStringImpl.cpp"
using namespace std;

//create a node

struct node{
	MyString name;
	int age;
	//address of next node
	node *next;	
};

int showMenu();
void handleChoice(int choice);

class LinkedListADT{
	private: node *head;
	 		 node *current;
			 node *previous;
			 node *end;
			 	
	public: //5 functions
	        LinkedListADT(); //create function
	        void add(node *temp);
	        void retrieve(node *temp);
	        void deleteNode(node *temp);
	        void print_list();
};
void LinkedListADT::deleteNode(node *temp){
	//delete temp
	while(current!=NULL){
		if(temp->name==current->name){
			previous->next=current->next;
			current=previous;
		}
		previous=current;
		current=current->next;
	}
	
}

void LinkedListADT::print_list(){
	node *temp;
	temp=new node;
	if(head!=NULL){
		current=head;
	
		while(current!=NULL){
			cout<<current->name<<endl;
			current=current->next;
		}
	}
	
	
}
void LinkedListADT::add(node *temp){
	if(head!=NULL) cout<<"HEAD IS CURRENTLY "<<head->name<<endl;
	cout<<"Temp's name "<<temp->name<<endl;
	 //if(temp->name>head->name) cout<<"TRUE!\n";
	if(head==NULL){
		temp->next=NULL;
		head=temp;
		cout<<"case 0\n";
	}
	 if(temp->name<head->name){
		temp->next=head;
		head=temp;
		cout<<"case 1\n";
	}	
	 else if((temp->name>head->name&&temp->name<end->name)){
	 	cout<<"case 2 begins\n";
		current=head;
		while((temp->name>current->name)){
			previous=current;
			current=current->next;
		}
		temp->next=current;
		previous->next=temp;
		cout<<"case 2\n";
	}
	else if(temp->name>end->name) {
		//case 3: End of list
   	current=head;
   	while(current->next!=NULL){
   		current=current->next;
	   }
	   current->next=temp;
	   current=temp;
	   current->next=NULL;
	   cout<<"case 3\n";
   }
   current=head;
   while(current->next!=NULL){
   		current=current->next;
	   }
	   end=current;
	   cout<<"Ender's name "<<end->name<<endl<<endl;
}

void LinkedListADT::retrieve(node *temp){
	current=head;
	while(current!=temp&&current->next!=NULL){
		current=current->next;
	}
	if(current==temp)cout<<current->name<<" and the next item in the link list is "<< current->next<<endl;
	else cout<<"not found man";

}

int showMenu(){
	int choice;
	cout<<"1. Create ---> creates or initializes a linked list using a constructor\n2. initialize all nodes (head, current, previous to NULL)\n3. add_node (book calls it store) --> uses the 3 cases\n4. remove --> deletes target node\n5. retrieve --> displays the target node\n6. print_list\n0. QUIT!\n";
	cin>>choice;
	return choice;
}
void handleChoice(int choice,LinkedListADT list){
	node *temp;
	while(choice!=0){
	temp= new node;
	MyString response;
	int ager;
	switch(choice){
		case 1:
			//create
			cout<<"the list has been created~!\n";
			break;
		case 2:
			//initalize all nodes (head, current, previous to NULL)
			
		

			break;
		case 3:
			//add node
			cin>>response;
			temp->name=response;
			list.add(temp);
			break;
		case 4:
			//remove target node
			cin>>response;
			temp->name=response;
			list.deleteNode(temp);
			choice=showMenu();
			break;
		case 5://retrieve a node
			cin>>response;
			cin>>ager;
			temp->name=response;
			temp->age=ager;
			 list.retrieve(temp);
			break;
		case 6:
			//print nodes;
			list.print_list();
			break;
		case 0://QUIT
			break;
	}
	choice=showMenu();
}
}



int main(){
	LinkedListADT list;
	handleChoice(showMenu(), list);
}
