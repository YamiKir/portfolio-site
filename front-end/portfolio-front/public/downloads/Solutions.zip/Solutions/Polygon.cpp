// A simple OpenGL program which draws a red triangle in a white window.
// c++ -w triangle.cpp -framework OpenGL -framework GLUT 

#include <glut.h>  //Change the location as needed to <GL/glut.h> or <glut.h>
#include <stdlib.h>

void display(void)
{
    glClearColor(1.0, 1.0, 1.0, 0.0);     // Specifiy window clearing (white) color
    glClear(GL_COLOR_BUFFER_BIT);         // Apply the clearing color
    glPointSize(10.0f);                   // Sets the size of the points


    glColor3f(1.0, 0.0, 0.0);             // Drawing red color
    glBegin(GL_POLYGON);                  // Draw a polygon
    glVertex2f(0.0, 0.8);                 // p1

    glColor3f(1.0, 1.0, 0.0);             // yellow
    glVertex2f(0.7, .4);                  // p2
    
    glColor3f(0.0, 1.0, 0.0);             // green
    glVertex2f(0.7, -.4);                 // p3

    glColor3f(0.0, 1.0, 1.0);             // cyan
    glVertex2f(0.0, -.8);                 // p4

    glColor3f(0.0, 0.0, 1.0);             // blue
    glVertex2f(-.7, -.4);                 // p5

    glColor3f(1.0, 0.0, 1.0);             // cyan
    glVertex2f(-.7, 0.4);                 // p6

    glEnd();
                         
    //----------------------------------------------
    glBegin(GL_POINTS);                   // points

    
    glColor3f(0.0, 0.0, 0.0);             // black

    glVertex2f(0.0, 0.8);               // p1
    glVertex2f(0.7, 0.4);               // p2
    glVertex2f(0.7, -0.4);              // p3
    glVertex2f(0.0, -0.8);              // p4
    glVertex2f(-0.7, -0.4);             // p5
    glVertex2f(-0.7, 0.4);              // p6

    glEnd();


    // x-axis
    glBegin(GL_LINES);
    glVertex2f(-1.0, 0.0); //x=-1
    glVertex2f(1.0, 0.0); // x=1
    glEnd();

    //y-axis
    glBegin(GL_LINES);
    glVertex2f(0.0, -1.0); //y=-1
    glVertex2f(0.0, 1.0);  //y=1
    glEnd();

    glFlush(); // Start drawing
    
                               
}

void keyboard(unsigned char key, int x, int y)
{
    switch (key) {			// Exit or close the display when press "esc" key
    case 27:
        exit(0);
        break;
    }
}


int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("A colorful polygon!");
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutMainLoop();
    return 0;
}