/* A simple solar system with a sun and a planet   */

#include <glut.h>
#include <stdlib.h>

static GLfloat year = 0.0, day = 0.0;

void display(void)
{
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glClear(GL_COLOR_BUFFER_BIT);

    glPushMatrix();		/* saves the current state by pushing in the stack */

    glRotatef(year, 0.0, 1.0, 0.0);
    glColor3f(1.0, 0.0, 0.0);
    glutWireSphere(1.0, 20, 16);        /* draws a sun in red */
    glutSolidSphere(1.0, 20, 16);


    glPushMatrix();

    glTranslatef(2.5, 0.0, 0.0);
    glRotatef(day*4, 0.0, 1.0, 0.0);
    glColor3f(0.0, 1.0, 0.0);
    glutWireSphere(0.4, 10, 8);	     /* draws a Mercury Green */
    glPopMatrix();

    glPushMatrix();
    glTranslatef(3.5, 0.0, 0.0);
    glRotatef(day*2, 0.0, 1.0, 0.0);
    glColor3f(1.0, 1.0, 0.0);
    glutWireSphere(0.3, 10, 8);	     /* draws a Yellow Venus */
    glPopMatrix();
    
    
    glTranslatef(6.0, 0.0, 0.0);
    glRotatef(day, 0.0, 1.0, 0.0);
    glColor3f(0.0, 0.0, 1.0);
    glutWireSphere(0.5, 10, 8);	     /* draws a Blue Earth */

   
    glTranslatef(.9, 0.0, 0.0);
    glRotatef(day*10,0.0, .866, 0.0);
    glColor3f(1.0, 1.0, 1.0);
    glutWireSphere(0.2, 10, 8); /* draws a White Moon */

    
    glPopMatrix();         /* restores the state before the rotations and translation */
    glutSwapBuffers();     /* swaps the front and back color buffers for animation */
}

void yearDisplay(void)
{
    year = year + 0.005;         // changing the angle for global (sun) rotation 
    if (year > 360.0)
        year = year - 360.0;
    day = day + .05;           // changing the angle for local (planet) rotation 
    if (day > 360.0)
        day = day - 360.0;

  
    glutPostRedisplay();
}

void reshape(int w, int h)
{
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(100, (GLfloat)w / (GLfloat)h, 1.0, 20.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(0.0, 0.0, 8.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
}

void keyboard(unsigned char key, int x, int y)
{
    switch (key) {
    case 'y':
        glutIdleFunc(yearDisplay);   // The rotation angles get updated
        break;
    case 'n':
        glutIdleFunc(NULL);
        break;
    case 27:
        exit(0);
        break;
    }
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(1920, 1080);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("A Simple Solar System");
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutMainLoop();
    return 0;
}