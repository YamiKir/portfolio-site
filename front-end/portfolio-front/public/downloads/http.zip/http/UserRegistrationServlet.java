import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

/**
 * Servlet implementation class UserRegistrationServlet
 */
@WebServlet("/UserRegistrationServlet")
@MultipartConfig
public class UserRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserRegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 final PrintWriter out = response.getWriter();
	        
	        String name = request.getParameter("name");
	        String email = request.getParameter("email");
	        String location = request.getParameter("location");
	        String gender = request.getParameter("gender");
	        String experience = request.getParameter("experience");
	        String fileName = request.getParameter("fileName");
	        
	        /*	
	         * request.getPart is to get the uploaded file handler. 
	         * You can use filePart.getInputStream() to read the streaming data from client, for example:
	         * InputStream filecontent = filePart.getInputStream();
	        */
		    Part filePart = request.getPart("file");
		    InputStream filecontent = filePart.getInputStream();
		    
		    /*
		     * fileout is for you to save the uploaded picture in your local disk. 
		     * */
		    OutputStream fileout = null;
		    	    
		    /*
		     * Write your code here
		     * Step 1: check whether the client's inputs are complete or not; if anything is missing, return a web page that contains a link to go back to the registration page (e.g., UserRegistration.html)
		     * Step 2: save the uploaded picture under your project WebContent directory, for example, mine is "F:\workspace\UserRegistrationProject\WebContent". 
		     * Step 3: send back the client's registration information to the client, remember, the client should be able to see all the information, including the profile picture. 
		     * */
		    
		    if(email==null||location==null||gender==null||experience==null||fileName==null||filecontent==null||filePart==null){
		    	response.sendRedirect("UserRegistrationFail.html");
		    	return;
		    }
		    //step 2

		 
		 String uploadDir = getServletContext().getRealPath("uploads/");//uploads folder

		 // Create the upload directory if it doesn't exist
		 File directory = new File(uploadDir);
		 if (!directory.exists()) {
		     directory.mkdirs();
		 }
		 
		 //file writer
		 OutputStream fileOutputStream = new FileOutputStream(new File(uploadDir, fileName));
		 byte[] buffer = new byte[1024];
		 int bytesRead;
		 while ((bytesRead = filecontent.read(buffer)) != -1) {
		     fileOutputStream.write(buffer, 0, bytesRead);
		 }

		 // Close the streams properly after writing the file
		 filecontent.close();
		 fileOutputStream.close();
		 //step 3
		 response.setContentType("text/html");

		//response in html
		 String htmlResponse = "<html><head><title>Welcome "+name+"</title></head><body>";
		 htmlResponse += "<h1>Welcome " + name + "</h1>";
		 htmlResponse += "<p>Your Name: " + name + "</p>";
		 htmlResponse += "<p>Your Email: " + email + "</p>";
		 htmlResponse += "<p>Your Location: " + location + "</p>";
		 htmlResponse += "<p>Your Gender: " + gender + "</p>";
		 htmlResponse += "<p>Your Experience: " + experience + "</p>";
		 htmlResponse += "<p>Profile Picture:" + fileName + " has been uploaded successfully:\n"+"<img src='uploads/" + fileName + "'></p>";
		 htmlResponse += "</body></html>";
		 out.println(htmlResponse);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}