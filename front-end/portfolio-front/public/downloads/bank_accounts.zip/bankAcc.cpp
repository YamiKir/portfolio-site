/*This program reads a list of usernames and pins and stores that info in an array 
the file is called "Accounts.txt" and it formatted like
Username
Pin
Username
...
Asks the user to attempt a login that is case sensitive 
Displays a simple menu and allows the user to edit&view their balance until they decide to quit the program

*/

#include <iostream>
#include<cstring>
#include <fstream>
using namespace std;
const int MAX=50;

#define exit_val 7848

struct Account{
	char FName[MAX];
	char LName[MAX];
	char ssNum[11];
	double balance=0;
	string userName;
	string pin;
};

int main(){
	
	string uPin; 
	fstream list;
	Account login[MAX];
	list.open("Accounts.txt");//opens a link to the file
	int i=0,choice;
	double trans;
	string uName;
	
	while (getline (list, login[i].userName)) {
  		getline (list, login[i].pin);
  		i++; //fills the array with accounts until the file is empty.
		}
		
	list.close(); //closes the link with the file
	cout<<"Enter your USERNAME (Case Sensitive): ";
	cin>>uName; //username
	cout<<"Enter your PIN(Case Sensitive): ";
	cin>>uPin; //password/ pin
		
		for(i; i>=0;i--){ //I counted down from i as it was equal to the number of inputted accs b/c of how the last loop worked.
			if(!login[i].userName.compare(uName) && !login[i].pin.compare(uPin)){
				cout<<"Good Job!\n";
				
				while(choice!=exit_val){
					cout<<"CHOOSE ONE OF THE FOllOWING: \n 1. Make a transaction\n 2. View Balance\n 3. Exit\n";
					cin>>choice;
					switch(choice){
						case 1://transaction
							cout<<"What's the amount you would like to modify your account by (use negative numbers for withdrawls)?\n";
							cin>>trans;
							login[i].balance+=trans;//adds any amount to the balance
							break;
						case 2://balance view
							cout<<"$"<<login[i].balance<<" is your account balance\n";
							break;
						case 3://quit
							choice=exit_val;
							break;
						default://ERROR
							cout<<"ERROR PLEASE TRY AGAIN!\n";
							choice=1;
							break;
					}
				}
			}
		}
	return 0;
}
