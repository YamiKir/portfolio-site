class Car:
    def __init__(self, year, made):
        self.__year_model= year
        self.__make=made
        self.__speed=0
    def accelerate(self):
        self.__speed+=5
    def brake(self):
        self.__speed-=5
    def get_speed(self):
        return float(self.__speed)
