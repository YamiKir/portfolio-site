import userInterface
import car
def main():
    carz= car.Car("2021","Toyota")
    my_user=userInterface.UserInterface(carz)       
main()
