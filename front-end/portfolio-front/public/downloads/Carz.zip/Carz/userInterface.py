import car
import tkinter
class UserInterface:
    def __init__(self, carz):
        self.carp=carz
        self.main_window= tkinter.Tk() #creates an tk window
        self.speedz=tkinter.StringVar() #creates a var variable to house the speed.
        self.canvas= tkinter.Canvas(self.main_window, width=200, height=200) #changes the window size
        self.top_frame=tkinter.Frame(self.main_window) # 3 frames
        self.middle_frame= tkinter.Frame(self.main_window)
        self.bottom_frame= tkinter.Frame(self.main_window)
        self.Accelerate=tkinter.Button(self.top_frame, text="Accelerate", command=self.UIAccel) #Accel button
        self.Brake= tkinter.Button(self.top_frame, text="Brake", command=self.UIBrake) #Brake Button
        self.speedLabelField= tkinter.Label(self.middle_frame, text="SPEED") # "speed" string 
        self.speedTextField= tkinter.Label(self.middle_frame, textvariable=self.speedz) #speed variable
        self.Cancel=tkinter.Button(self.bottom_frame, text="Cancel", command=self.main_window.destroy) #button that closes the window
        self.Accelerate.pack(side='left') #packing
        self.Brake.pack(side='right')
        self.Cancel.pack()
        self.speedLabelField.pack(side='left')
        self.speedTextField.pack(side='right')
        self.top_frame.pack()
        self.middle_frame.pack()
        self.bottom_frame.pack()
        self.canvas.pack()
        tkinter.mainloop() #loops
    def displaySpeed(self): # sets the speed from carp to v  and then to speedz
        v=self.carp.get_speed()
        self.speedz.set(v)
        
    def UIAccel(self): # Accels Carp
        self.carp.accelerate()
        self.displaySpeed()
    def UIBrake(self): #Brakes Carp
        self.carp.brake()
        self.displaySpeed()
