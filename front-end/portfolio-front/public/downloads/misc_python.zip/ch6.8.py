def read():
    outfile=open('ranNum.txt','r') #opens the file in read
    line=outfile.readline()
    counter=0 #for totals
    print("Here's the values from the file:")
    while line !='': # checks for empty string
        print(line) #prints number
        line=outfile.readline()
        counter+=1 #counts
    print("There were a total of ", counter, " numbers in this file")
read()
        
