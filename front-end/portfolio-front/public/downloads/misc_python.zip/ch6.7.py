import random
def main():
    loops=int(input("Enter the number of random numbers should be generated: "))  #lets user decide how many numbers are created
    outfile=open('ranNum.txt', 'w')  #opens/creates file
    for x in range (loops):
        outfile.write(str(random.randrange(1,501))+ '\n')  #writes a random num from 1-500 and adds a space
    outfile.close() #after the loop, file closes and saves
main()
              
