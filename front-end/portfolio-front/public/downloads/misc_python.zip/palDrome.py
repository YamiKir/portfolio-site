def write():
    file=open('palFile.txt','w')
    pal3="0"
    for x in range(999,500,-1):
        for y in range (999,500,-1):
            pal=str(x*y)
            pal2=pal[::-1]
            file.write(str(x)+" "+ str(y)+" "+pal+"\n")
            if (pal==pal2): file.write(pal+ "is a palidrome\n")
            if(pal>pal3 and pal==pal2): pal3=pal
    print(pal3)
    file.close()
write()
