num=float(int(input("Find out if a number is Perfect: " ))) #collects a number 
counter=0                           #the summation varable 
halfish=int(num//2+1)               #the largest whole factor of a number is half of the number
for i in range(1,halfish):          #loops and finds the factors
    if (num%i==0): counter=counter+i#loops and finds the factors
    if (num%i==0): print(i)         #displays the current factor (for debugging really)
if (counter==num): print("Perfect") #displays the status of the number 
if (counter>num): print("Abudant")  #displays the status of the number 
if (counter< num): print("Deficient ")#displays the status of the number 
    
            
