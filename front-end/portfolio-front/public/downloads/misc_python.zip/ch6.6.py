def read():
    try : #added for 6.9
        outfile=open('numbers.txt','r') #opens the file in read
        line=outfile.readline()
        counter=0 #for total # of numbers
        sumz=0 # for total of sum
        while line !='': # checks for empty string
            sumz+=int(line)        
            line=outfile.readline()
            counter+=1 #counts
        print("There were a total of ", counter, " numbers in this file")
        print("The total was ", sumz)
        print("The average is ", sumz/counter)
        outfile.close()
    except ValueError: #added for 6.9
        print("ERROR: NUMBERS MUST ONLY INCLUDE INTEGERS")
        read()
    except IOError: #added for 6.9
        print("An error occured when trying to read \'numbers.txt\'")
read()
