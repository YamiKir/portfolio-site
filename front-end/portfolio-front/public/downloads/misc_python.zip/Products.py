product=1
while product<100:
    product=float(input("insert a number:"))*product
    print("new product:", product)
    
