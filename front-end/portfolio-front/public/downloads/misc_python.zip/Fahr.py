c=float(input('Temperature in C?:'))
f=9.0/5*c+32
print(f)
