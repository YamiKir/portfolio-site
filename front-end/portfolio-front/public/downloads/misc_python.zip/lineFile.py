def read():
    outfile=open('linesFile.txt','r') #opens the file in read
    line=outfile.readline()
    counter=0 #for totals
    print("Here's the values from the file:")
    while line !='': # checks for empty string
        counter+=1
        print(counter,":", line.rstrip('\n')) #prints number
        line=outfile.readline()
    outfile.close()
#here's them together
read()
