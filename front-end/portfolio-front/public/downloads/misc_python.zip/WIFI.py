print("Want to play a game? Try to reach exactly a dollar using various amounts of coins")
coins=float(input("how many pennies?"))
coins=coins+float(input("how many nickels?"))*5
coins=coins+float(input("how many dimes?"))*10
coins=coins+float(input("how many quarters?"))*25
coins=coins+float(input("how many half-dollars?"))*50
coins=coins+float(input("how many dollar coins?"))*100
coins=coins/100
if (coins==1): print("you win!")
else: print("you lose")
