P=float(input("input the prinipal: "))
r=float(input("input the interest rate (as a percent minus the symbol): "))/100
n=float(input('input the number of coumpounds:' ))
t=float(input('input the number of years:' ))
print("Final amount: ",format(P*(1+r/n)**(n*t),".2f"))
