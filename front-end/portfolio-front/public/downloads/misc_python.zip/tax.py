
price=float(input('What is the price?:'))
taxState=.05*price
taxLocal=.025*price
total=taxState+taxLocal+price
print('Pre-tax:', price)
print('State Tax:', taxState)
print('County Tax:', taxLocal)
print('Total:', total)
