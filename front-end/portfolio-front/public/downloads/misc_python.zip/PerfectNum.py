num=float(int(input("Find out if a number is Perfect: " ))) #collects a number 
counter=num                         #the summation varable set as the orginal num
halfish=int(num//2+1)               #the largest whole (nonprime) factor of a number is half of the number
print(int(num))                     #displays the largest factor/ the number at the top
for i in range(1,halfish):          #loops and finds the factors
    if (num%i==0): counter=counter+i#loops and finds the factors
    if (num%i==0): print(i)         #displays the current factor (for debugging really)
if (counter==num): print("Perfect") #displays the status of the number 
if (counter>num): print("Abudant")  #displays the status of the number 
if (counter< num): print("Deficient ")#displays the status of the number 


    
            
