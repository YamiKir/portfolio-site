print("Melting and Boiling Points of Alkanes")
print("Name","Melting Point (deg C)", "Boiling Point(deg C)", sep="     ")
print("Methane",format(" -162","26s"),"-183")
print("Ethane",format("  -89","27s"), "-172")
print("Propane",format(" -42","26s"), "-188")
print("Butane",format("  -0.5","27s"), "-135")
print("/n /n")
print("Melting and Boiling Points of Alkanes")
print("Name","Melting Point (deg C)", "Boiling Point(deg C)", sep="     ")
print("Methane {:5d} {:25}".format(-162,-183))
print("Ethane {:5d} {:26}".format(-89, -172))
print("Propane {:4d} {:26}".format( -42,-188))
print("Butane {:6.1f} {:25}".format(-0.5,-135))



