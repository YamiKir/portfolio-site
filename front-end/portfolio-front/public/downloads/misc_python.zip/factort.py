def main():
    factor=100000000
    limit=(4*9*5*7*11*13*17*19)
    for f in range (1,2521):
        for x in range(1, 11):
            if(f%x): f+=1
           print(f%x)
           print("the remanider is: ", f%x, " for ", f, " divided by ", x)
        if (x==20 and factor<limit): factor=limit
        limit-=1
    print(limit)
    print(factor)
main()
        
    
