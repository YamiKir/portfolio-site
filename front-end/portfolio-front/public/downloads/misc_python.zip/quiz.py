response= 0
sum=0
while(response!='.'):
    response=(input("input an even number (. to stop or an odd):"))
    if(response=='.'): break
    response=int(response)
    if(response%2==1): break
    sum=sum+response
print(sum, " was the sum")
