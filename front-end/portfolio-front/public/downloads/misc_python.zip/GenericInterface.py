import tkinter
class UserInterface:
    def __init__(self):
        self.main_window=tkinter.Tk()
        self.canvas= tkinter.Cancas(self.main_window, width=300, height= 300)
        self.top_frame=tkinter.Frame(self.main_window)
        self.middle_frame=tkinter.Frame(self.main_window)
        self.bottom_frame=tkinter.Frame(self.main_window)








        self.top_frame.pack()
        self.middle_frame.pack()
        self.bottom_frame.pack()
        self.canvas.pack()
        tkinter.mainloop()
